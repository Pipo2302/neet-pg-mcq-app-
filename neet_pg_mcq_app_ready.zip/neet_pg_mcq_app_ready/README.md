# NEET-PG MCQ Practice

Flutter Android app generated from the supplied `CORE btr.apkg` Anki collection.

- 10,800 imported MCQs
- Subjects/topics derived from Anki qBank decks
- Question explanations and references
- Remote question images retained from the source HTML
- Practice, custom tests, bookmarks, wrong questions
- Daily target and progress saved locally
- Light/dark mode
- Search

## Build

```bash
flutter pub get
flutter build apk --release
```

The project contains the Android wrapper so Codemagic can build it directly.
