
import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() => runApp(const NeetPgApp());

class Mcq {
  final int id;
  final String mcqId, question, explanation, subject, topic, answer, references;
  final List<String> options;
  final int correctIndex;
  final List<String> imageUrls;
  Mcq(Map<String,dynamic> j)
      : id = (j['id'] as num?)?.toInt() ?? 0,
        mcqId = '${j['mcq_id'] ?? ''}',
        question = '${j['question'] ?? ''}',
        explanation = '${j['explanation'] ?? ''}',
        subject = '${j['subject'] ?? ''}',
        topic = '${j['topic'] ?? ''}',
        answer = '${j['correct_answer'] ?? ''}',
        references = '${j['references'] ?? ''}',
        options = List<String>.from(j['options'] ?? const []),
        correctIndex = (j['correct_index'] as num?)?.toInt() ?? 0,
        imageUrls = List<String>.from(j['image_urls'] ?? const []);
}

class NeetPgApp extends StatefulWidget {
  const NeetPgApp({super.key});
  @override State<NeetPgApp> createState() => _NeetPgAppState();
}
class _NeetPgAppState extends State<NeetPgApp> {
  bool dark = false;
  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) setState(() => dark = p.getBool('dark') ?? false);
  }
  Future<void> toggle() async {
    final p = await SharedPreferences.getInstance();
    final v = !dark; await p.setBool('dark', v);
    if (mounted) setState(() => dark = v);
  }
  ThemeData theme(Brightness b) => ThemeData(
    useMaterial3: true, brightness: b, colorSchemeSeed: const Color(0xFF4154D8),
    scaffoldBackgroundColor: b == Brightness.light ? const Color(0xFFF6F7FB) : const Color(0xFF101116),
    cardTheme: const CardThemeData(margin: EdgeInsets.zero),
  );
  @override Widget build(BuildContext c) => MaterialApp(
    debugShowCheckedModeBanner:false, title:'NEET-PG MCQ', theme:theme(Brightness.light),
    darkTheme:theme(Brightness.dark), themeMode:dark?ThemeMode.dark:ThemeMode.light,
    home: HomePage(onTheme:toggle, dark:dark),
  );
}

class HomePage extends StatefulWidget {
  final VoidCallback onTheme; final bool dark;
  const HomePage({super.key,required this.onTheme,required this.dark});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  List<Mcq> all=[]; Set<int> wrong={}, bookmarks={}, attempted={}, correct={};
  int target=30, today=0, tab=0; bool loading=true;
  @override void initState(){super.initState();_load();}
  Set<int> setOf(SharedPreferences p,String k)=>(p.getStringList(k)??[]).map(int.tryParse).whereType<int>().toSet();
  Future<void> _load() async {
    final raw=await rootBundle.loadString('assets/mcqs.json');
    final qs=(jsonDecode(raw) as List).map((e)=>Mcq(Map<String,dynamic>.from(e))).toList();
    final p=await SharedPreferences.getInstance(); final day=DateTime.now().toIso8601String().substring(0,10);
    if(p.getString('day')!=day){await p.setString('day',day);await p.setInt('today',0);}
    if(!mounted)return;
    setState((){all=qs;wrong=setOf(p,'wrong');bookmarks=setOf(p,'bookmarks');attempted=setOf(p,'attempted');correct=setOf(p,'correct');target=p.getInt('target')??30;today=p.getInt('today')??0;loading=false;});
  }
  Future<void> save() async {
    final p=await SharedPreferences.getInstance();
    for(final e in {'wrong':wrong,'bookmarks':bookmarks,'attempted':attempted,'correct':correct}.entries)
      await p.setStringList(e.key,e.value.map((x)=>'$x').toList());
    await p.setInt('target',target); await p.setInt('today',today);
  }
  void open(List<Mcq> qs,{String title='Practice',bool test=false,int minutes=0}){
    if(qs.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('No questions available.')));return;}
    Navigator.push(context,MaterialPageRoute(builder:(_)=>PracticePage(
      questions:qs,title:title,testMode:test,minutes:minutes,bookmarks:bookmarks,
      onState:(id,isCorrect,isWrong,isBookmarked){setState((){
        attempted.add(id); today++;
        if(isCorrect){correct.add(id);wrong.remove(id);} else {wrong.add(id);correct.remove(id);}
        if(isBookmarked)bookmarks.add(id); else bookmarks.remove(id);
      });save();},
    )));
  }
  double get accuracy=>attempted.isEmpty?0:correct.length/attempted.length*100;
  @override Widget build(BuildContext c){
    if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    return Scaffold(body:IndexedStack(index:tab,children:[
      _home(), SubjectPage(all:all,onOpen:open), ProgressPage(all:all,attempted:attempted,correct:correct,wrong:wrong),
      SettingsPage(target:target,onTarget:(v){setState(()=>target=v);save();},dark:widget.dark,onTheme:widget.onTheme)
    ]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),
      destinations:const[
        NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),
        NavigationDestination(icon:Icon(Icons.menu_book_outlined),selectedIcon:Icon(Icons.menu_book),label:'Subjects'),
        NavigationDestination(icon:Icon(Icons.insights_outlined),selectedIcon:Icon(Icons.insights),label:'Progress'),
        NavigationDestination(icon:Icon(Icons.settings_outlined),selectedIcon:Icon(Icons.settings),label:'Settings'),
      ]));
  }
  Widget _home()=>CustomScrollView(slivers:[
    SliverAppBar(pinned:true,title:const Text('NEET-PG',style:TextStyle(fontWeight:FontWeight.w900)),actions:[
      IconButton(icon:const Icon(Icons.search),onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SearchPage(all:all,onOpen:open)))),
      IconButton(icon:Icon(widget.dark?Icons.light_mode:Icons.dark_mode),onPressed:widget.onTheme)]),
    SliverPadding(padding:const EdgeInsets.all(16),sliver:SliverList(delegate:SliverChildListDelegate([
      _hero(),const SizedBox(height:16),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[
        Row(children:[const Icon(Icons.local_fire_department),const SizedBox(width:8),const Text('Daily Target',style:TextStyle(fontWeight:FontWeight.w800)),const Spacer(),Text('$today / $target')])),
        const SizedBox(height:10),LinearProgressIndicator(value:min(1,today/max(1,target)),minHeight:8),
      ]))),const SizedBox(height:20),_section('Quick Practice'),
      _action('Practice All','Random • up to 100 questions',Icons.play_circle_fill,(){final q=[...all]..shuffle();open(q.take(min(100,q.length)).toList());}),
      _action('Custom Test','25 / 50 / 100 • subject filter + timer',Icons.timer,()=>_customTest()),
      _action('Wrong Questions','${wrong.length} questions need revision',Icons.error_outline,()=>open(all.where((q)=>wrong.contains(q.id)).toList(),title:'Wrong Questions')),
      _action('Bookmarks','${bookmarks.length} saved questions',Icons.bookmark,()=>open(all.where((q)=>bookmarks.contains(q.id)).toList(),title:'Bookmarks')),
      const SizedBox(height:14),_section('High-Yield Tools'),
      _action('Search MCQs','Find by question, topic or explanation',Icons.manage_search,()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>SearchPage(all:all,onOpen:open)))),
      _action('Progress Analytics','Accuracy, attempted, wrong & subject coverage',Icons.analytics,()=>setState(()=>tab=2)),
    ])))
  ]);
  Widget _hero()=>Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(borderRadius:BorderRadius.circular(26),gradient:LinearGradient(colors:[Theme.of(context).colorScheme.primary,Theme.of(context).colorScheme.tertiary])),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    const Text('YOUR PREP HUB',style:TextStyle(color:Colors.white70,fontSize:12,fontWeight:FontWeight.bold,letterSpacing:1.2)),
    const SizedBox(height:5),Text('${all.length} MCQs',style:const TextStyle(color:Colors.white,fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:16),
    Row(children:[_stat('${attempted.length}','Attempted'),_stat('${accuracy.toStringAsFixed(0)}%','Accuracy'),_stat('${all.map((e)=>e.subject).toSet().length}','Subjects')])
  ]);
  Widget _stat(String a,String b)=>Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:Colors.white,fontSize:20,fontWeight:FontWeight.w800)),Text(b,style:const TextStyle(color:Colors.white70,fontSize:12))]));
  Widget _section(String s)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Text(s,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w900)));
  Widget _action(String t,String s,IconData i,VoidCallback f)=>Padding(padding:const EdgeInsets.only(bottom:10),child:Card(child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:16,vertical:6),leading:Icon(i),title:Text(t,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(s),trailing:const Icon(Icons.chevron_right),onTap:f)));
  Future<void> _customTest()async{
    final r=await showModalBottomSheet<Map<String,dynamic>>(context:context,isScrollControlled:true,showDragHandle:true,builder:(_)=>TestBuilder(all:all));
    if(r==null)return;var q=[...all];
    final sub=r['subject'] as String?; if(sub!=null)q=q.where((x)=>x.subject==sub).toList();
    q.shuffle();final n=min(r['count'] as int,q.length);open(q.take(n).toList(),title:'Custom Test',test:true,minutes:n);
  }
}

class TestBuilder extends StatefulWidget{
  final List<Mcq> all; const TestBuilder({super.key,required this.all});
  @override State<TestBuilder> createState()=>_TestBuilderState();
}
class _TestBuilderState extends State<TestBuilder>{
  int count=25;String? subject;
  @override Widget build(BuildContext c){final subs=widget.all.map((e)=>e.subject).where((e)=>e.isNotEmpty).toSet().toList()..sort();
    return SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(20,8,20,20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('Create Test',style:Theme.of(c).textTheme.headlineSmall?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:16),
      const Text('Questions',style:TextStyle(fontWeight:FontWeight.bold)),Wrap(spacing:8,children:[25,50,100].map((n)=>ChoiceChip(label:Text('$n'),selected:count==n,onSelected:(_)=>setState(()=>count=n))).toList()),
      const SizedBox(height:14),DropdownButtonFormField<String>(value:subject,decoration:const InputDecoration(labelText:'Subject (optional)'),
        items:[const DropdownMenuItem<String>(value:null,child:Text('All subjects')),...subs.map((s)=>DropdownMenuItem(value:s,child:Text(s)))],onChanged:(v)=>setState(()=>subject=v)),
      const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:()=>Navigator.pop(c,{'count':count,'subject':subject}),icon:const Icon(Icons.play_arrow),label:const Text('START TEST')))
    ])));
  }
}

class SubjectPage extends StatelessWidget{
  final List<Mcq> all;final void Function(List<Mcq>) onOpen;
  const SubjectPage({super.key,required this.all,required this.onOpen});
  @override Widget build(BuildContext c){final map=<String,List<Mcq>>{};for(final q in all)map.putIfAbsent(q.subject.isEmpty?'Other':q.subject,()=>[]).add(q);
    final e=map.entries.toList()..sort((a,b)=>a.key.compareTo(b.key));
    return Scaffold(appBar:AppBar(title:const Text('Subjects',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView.builder(padding:const EdgeInsets.all(14),itemCount:e.length,itemBuilder:(_,i)=>Card(margin:const EdgeInsets.only(bottom:9),child:ListTile(
      leading:CircleAvatar(child:Text('${e[i].value.length}')),title:Text(e[i].key,style:const TextStyle(fontWeight:FontWeight.w800)),
      subtitle:Text('${e[i].value.map((q)=>q.topic).where((t)=>t.isNotEmpty).toSet().length} topics'),trailing:const Icon(Icons.chevron_right),onTap:()=>onOpen(e[i].value,title:e[i].key))));
  }
}

class SearchPage extends StatefulWidget{
  final List<Mcq> all;final void Function(List<Mcq>) onOpen;
  const SearchPage({super.key,required this.all,required this.onOpen});
  @override State<SearchPage> createState()=>_SearchPageState();
}
class _SearchPageState extends State<SearchPage>{
  String q='';
  @override Widget build(BuildContext c){final r=widget.all.where((x){final s='${x.question} ${x.subject} ${x.topic} ${x.explanation}'.toLowerCase();return q.trim().isEmpty||s.contains(q.toLowerCase());}).take(200).toList();
    return Scaffold(appBar:AppBar(title:TextField(autofocus:true,decoration:const InputDecoration(hintText:'Search MCQs…',border:InputBorder.none),onChanged:(v)=>setState(()=>q=v))),
      body:ListView.separated(padding:const EdgeInsets.all(12),itemCount:r.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(_,i)=>Card(child:ListTile(
        title:Text(r[i].question,maxLines:3,overflow:TextOverflow.ellipsis),subtitle:Text('${r[i].subject}${r[i].topic.isEmpty?'':' • ${r[i].topic}'}'),onTap:()=>widget.onOpen([r[i]],title:'Question')))));
  }
}

class ProgressPage extends StatelessWidget{
  final List<Mcq> all;final Set<int> attempted,correct,wrong;
  const ProgressPage({super.key,required this.all,required this.attempted,required this.correct,required this.wrong});
  @override Widget build(BuildContext c){final acc=attempted.isEmpty?0.0:correct.length/attempted.length*100;final map=<String,int>{};
    for(final q in all)map[q.subject]=(map[q.subject]??0)+1;
    return Scaffold(appBar:AppBar(title:const Text('Progress & Analytics',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(16),children:[
      Card(child:Padding(padding:const EdgeInsets.all(20),child:Column(children:[Text('${acc.toStringAsFixed(1)}%',style:Theme.of(c).textTheme.displayMedium?.copyWith(fontWeight:FontWeight.w900)),const Text('Overall accuracy'),const SizedBox(height:18),LinearProgressIndicator(value:acc/100,minHeight:10),const SizedBox(height:18),Row(mainAxisAlignment:MainAxisAlignment.spaceAround,children:[_m('${attempted.length}','Attempted'),_m('${correct.length}','Correct'),_m('${wrong.length}','Wrong'),_m('${all.length-attempted.length}','Unseen')])]))),
      const SizedBox(height:18),Text('Subject coverage',style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:10),
      ...map.entries.map((e)=>Card(margin:const EdgeInsets.only(bottom:8),child:ListTile(title:Text(e.key),trailing:Text('${e.value}'))))
    ]));
  }
  Widget _m(String a,String b)=>Column(children:[Text(a,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)),Text(b,style:const TextStyle(fontSize:11))]);
}

class SettingsPage extends StatelessWidget{
  final int target;final ValueChanged<int> onTarget;final bool dark;final VoidCallback onTheme;
  const SettingsPage({super.key,required this.target,required this.onTarget,required this.dark,required this.onTheme});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Settings',style:TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.all(16),children:[
    Card(child:ListTile(leading:const Icon(Icons.flag),title:const Text('Daily MCQ target'),subtitle:Text('$target questions per day'),trailing:DropdownButton<int>(value:target,items:[10,20,30,50,100].map((x)=>DropdownMenuItem(value:x,child:Text('$x'))).toList(),onChanged:(v){if(v!=null)onTarget(v);}))),
    Card(child:SwitchListTile(title:const Text('Dark mode'),value:dark,onChanged:(_)=>onTheme())),
    const Card(child:ListTile(leading:Icon(Icons.cloud_off),title:Text('MCQ bank is bundled in the app'),subtitle:Text('Question data works without internet. Images may require internet when their source is remote.'))),
    const Card(child:ListTile(leading:Icon(Icons.info_outline),title:Text('About'),subtitle:Text('NEET-PG MCQ Practice • Anki import • 10,800 questions')))
  ]);
}

class PracticePage extends StatefulWidget{
  final List<Mcq> questions;final bool testMode;final int minutes;final String title;final Set<int> bookmarks;
  final void Function(int,bool,bool,bool) onState;
  const PracticePage({super.key,required this.questions,required this.bookmarks,required this.onState,this.testMode=false,this.minutes=0,this.title='Practice'});
  @override State<PracticePage> createState()=>_PracticePageState();
}
class _PracticePageState extends State<PracticePage>{
  int index=0;late Set<int> saved;late List<int?> answers;late List<bool> submitted;Timer? timer;int seconds=0;bool done=false;
  Mcq get q=>widget.questions[index];
  @override void initState(){super.initState();saved={...widget.bookmarks};answers=List.filled(widget.questions.length,null);submitted=List.filled(widget.questions.length,false);
    if(widget.testMode){seconds=widget.minutes*60;timer=Timer.periodic(const Duration(seconds:1),(_){if(!mounted)return;if(seconds<=1){timer?.cancel();finish();}else setState(()=>seconds--);});}}
  @override void dispose(){timer?.cancel();super.dispose();}
  bool correctNow(){if(answers[index]==null||q.correctIndex<0)return false;return answers[index]==q.correctIndex;}
  void submit(){if(answers[index]==null||submitted[index])return;final ok=correctNow();setState(()=>submitted[index]=true);widget.onState(q.id,ok,!ok,saved.contains(q.id));}
  void finish(){timer?.cancel();if(mounted)setState(()=>done=true);}
  @override Widget build(BuildContext c){if(done)return _result(c);return Scaffold(appBar:AppBar(title:Text(widget.title),actions:[
    if(widget.testMode)Padding(padding:const EdgeInsets.all(14),child:Center(child:Text('${seconds~/60}:${(seconds%60).toString().padLeft(2,'0')}',style:const TextStyle(fontWeight:FontWeight.bold))))
  ]),body:ListView(padding:const EdgeInsets.fromLTRB(16,10,16,28),children:[
    Row(children:[Text('${index+1} / ${widget.questions.length}',style:const TextStyle(fontWeight:FontWeight.w800)),const Spacer(),IconButton(icon:Icon(saved.contains(q.id)?Icons.bookmark:Icons.bookmark_border),onPressed:()=>setState(()=>saved.contains(q.id)?saved.remove(q.id):saved.add(q.id)))]),
    if(q.subject.isNotEmpty)Text('${q.subject}${q.topic.isEmpty?'':' • ${q.topic}'}',style:Theme.of(c).textTheme.labelLarge),
    const SizedBox(height:10),Text(q.question,style:Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.w700)),
    ...q.imageUrls.map((u)=>Padding(padding:const EdgeInsets.symmetric(vertical:10),child:ClipRRect(borderRadius:BorderRadius.circular(12),child:Image.network(u,errorBuilder:(_,__,___)=>const SizedBox.shrink(),loadingBuilder:(c,w,p)=>p==null?w:const Padding(padding:EdgeInsets.all(20),child:Center(child:CircularProgressIndicator())))))),
    const SizedBox(height:8),...List.generate(q.options.length,(i){final selected=answers[index]==i;final show=submitted[index];final isAns=i==q.correctIndex;return Card(color:show&&isAns?Theme.of(c).colorScheme.primaryContainer:null,child:RadioListTile<int>(value:i,groupValue:answers[index],onChanged:show?null:(v)=>setState(()=>answers[index]=v),title:Text(q.options[i]),secondary:show?Icon(isAns?Icons.check_circle: (selected?Icons.cancel:Icons.radio_button_unchecked)):null));}),
    const SizedBox(height:10),if(!submitted[index])FilledButton(onPressed:answers[index]==null?null:submit,child:const Text('SUBMIT ANSWER')),
    if(submitted[index])Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(correctNow()?'✓ Correct':'✗ Incorrect',style:TextStyle(fontWeight:FontWeight.w900,color:correctNow()?Colors.green:Colors.red)),if(q.explanation.isNotEmpty)...[const SizedBox(height:8),const Text('Explanation',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:4),Text(q.explanation)],if(q.references.isNotEmpty)...[const SizedBox(height:8),const Text('References',style:TextStyle(fontWeight:FontWeight.bold)),Text(q.references)]
    ]))),
    if(submitted[index])FilledButton.icon(onPressed:()=>index<widget.questions.length-1?setState(()=>index++):finish(),icon:Icon(index<widget.questions.length-1?Icons.arrow_forward:Icons.check),label:Text(index<widget.questions.length-1?'NEXT':'FINISH')),
    if(index>0)TextButton(onPressed:()=>setState(()=>index--),child:const Text('Previous'))
  ]);}
  Widget _result(BuildContext c){int a=0;for(var i=0;i<answers.length;i++)if(answers[i]!=null&&answers[i]==widget.questions[i].correctIndex)a++;return Scaffold(appBar:AppBar(title:const Text('Test Result')),body:Center(child:Padding(padding:const EdgeInsets.all(24),child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    Text('$a / ${widget.questions.length}',style:Theme.of(c).textTheme.displayMedium?.copyWith(fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('Score • ${(a/max(1,widget.questions.length)*100).toStringAsFixed(1)}%'),
    const SizedBox(height:24),FilledButton(onPressed:()=>Navigator.pop(c),child:const Text('BACK TO HOME'))
  ])));}
}
