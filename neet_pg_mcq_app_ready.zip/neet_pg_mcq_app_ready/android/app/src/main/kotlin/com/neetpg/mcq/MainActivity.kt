package com.neetpg.mcq

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
